CREATE PROCEDURE SP_Proveedor_Listar
AS
SELECT
	CodigoProveedor, 
	ISNULL(NombreProveedor,'Nombre Vacio') AS NombreProveedor,
	ISNULL(DescripcionProveedor,'Descripcion Vacia') AS DescripcionProveedor
FROM Proveedor;
go

