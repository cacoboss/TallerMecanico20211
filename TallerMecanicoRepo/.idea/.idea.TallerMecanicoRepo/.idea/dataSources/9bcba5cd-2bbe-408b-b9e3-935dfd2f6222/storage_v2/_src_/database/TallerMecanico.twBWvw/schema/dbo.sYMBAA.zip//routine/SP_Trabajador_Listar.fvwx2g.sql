CREATE PROCEDURE SP_Trabajador_Listar
AS
SELECT
	Cedula,
	Nombres,
	Apellidos,
	Celular,
	TipoTrabajador,
	DireccionCorreoElectronico AS Correo,
	Contraseña AS Clave
FROM 
	Trabajador
go

