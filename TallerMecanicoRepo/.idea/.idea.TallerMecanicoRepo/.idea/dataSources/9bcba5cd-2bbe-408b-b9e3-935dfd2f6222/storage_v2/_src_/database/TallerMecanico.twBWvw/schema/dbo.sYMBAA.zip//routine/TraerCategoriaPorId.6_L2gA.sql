CREATE PROCEDURE [dbo].[TraerCategoriaPorId]
@ID int
AS
SELECT IdCategoria [Id],
	ISNULL(CodigoCategoria,'')[Codigo],
	ISNULL(Nombre,'')[Nombre],
	ISNULL(Observacion,'')[Observacion]	
FROM Categoria
WHERE IdCategoria = @ID
go

