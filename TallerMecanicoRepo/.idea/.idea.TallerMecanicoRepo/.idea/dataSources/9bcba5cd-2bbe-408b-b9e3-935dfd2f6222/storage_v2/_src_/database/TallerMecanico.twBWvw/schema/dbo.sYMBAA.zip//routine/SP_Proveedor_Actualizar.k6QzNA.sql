CREATE PROCEDURE SP_Proveedor_Actualizar
	@ID				INT,
	@NOMBRE			NVARCHAR(50),
	@DESCRIPCION	TEXT
AS
UPDATE Proveedor
SET
	NombreProveedor			= @NOMBRE,
	DescripcionProveedor	= @DESCRIPCION,
	FechaModificacion		= GETDATE()
WHERE
	CodigoProveedor			= @ID;
go

