CREATE PROCEDURE SP_Productos_TraerPorID
	@ID			INT
AS
SELECT
	CodigoProducto,
	ISNULL(CodigoCategoria, 0) AS CodigoCategoria,
	ISNULL(DescripcionProducto, 'Valor Nulo') AS DescripcionProducto,
	ISNULL(ValorUnitarioCompra, 0) AS ValorUnitarioCompra,
	ISNULL(ValorUnitarioVenta, 0) AS ValorUnitarioVenta,
	ISNULL(Marca, 'Valor Nulo') as Marca,
	ISNULL(NombreProducto, 'Valor Nulo') AS NombreProducto
FROM Productos
WHERE CodigoProducto = @ID
go

