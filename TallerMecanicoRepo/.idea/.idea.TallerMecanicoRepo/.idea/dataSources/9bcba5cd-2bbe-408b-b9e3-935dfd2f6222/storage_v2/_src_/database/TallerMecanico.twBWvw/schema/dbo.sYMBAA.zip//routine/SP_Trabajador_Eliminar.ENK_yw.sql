CREATE PROCEDURE SP_Trabajador_Eliminar
	@ID			BIGINT
AS
DELETE 
	FROM Trabajador
WHERE
	Cedula = @ID;
go

