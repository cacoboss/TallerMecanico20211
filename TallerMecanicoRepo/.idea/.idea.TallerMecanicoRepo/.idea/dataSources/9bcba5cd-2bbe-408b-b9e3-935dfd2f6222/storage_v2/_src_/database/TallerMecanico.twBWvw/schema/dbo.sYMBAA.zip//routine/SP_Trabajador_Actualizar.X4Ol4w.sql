CREATE PROCEDURE SP_Trabajador_Actualizar
	@CEDULA		BIGINT,
	@NOMBRES	NVARCHAR(50),
	@APELLIDOS	NVARCHAR(50),
	@CELULAR	BIGINT,
	@TIPO		INT,
	@CORREO		NVARCHAR(50),
	@CLAVE		NVARCHAR(50)
AS
UPDATE Trabajador
SET 
	Cedula						= @CEDULA,
	Nombres						= @NOMBRES,
	Apellidos					= @APELLIDOS,
	Celular						= @CELULAR,
	TipoTrabajador				= @TIPO,
	Contraseña					= @CLAVE,
	DireccionCorreoElectronico = @CORREO,
	FechaModificacion			= GETDATE()
WHERE
	Cedula = @CEDULA;
go

