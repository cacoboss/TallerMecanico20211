CREATE PROCEDURE EliminarCategoria
	@ID INT
AS
DELETE FROM Categoria
WHERE IdCategoria = @ID
go

