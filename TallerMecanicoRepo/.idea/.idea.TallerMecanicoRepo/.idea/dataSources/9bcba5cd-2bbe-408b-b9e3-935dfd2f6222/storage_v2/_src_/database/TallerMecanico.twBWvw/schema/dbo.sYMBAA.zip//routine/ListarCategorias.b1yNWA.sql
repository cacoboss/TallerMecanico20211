-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
-- SET ANSI_NULLS ON
-- GO
-- SET QUOTED_IDENTIFIER ON
-- GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[ListarCategorias] 
	-- Add the parameters for the stored procedure here
	
AS
SELECT [dbo].[Categoria].[IdCategoria] [Id],
	ISNULL(Categoria.CodigoCategoria,'') [Codigo],
	ISNULL(Categoria.Nombre, '')[Nombre],
	ISNULL(Categoria.Observacion, '')[Observacion]
FROM Categoria

go

