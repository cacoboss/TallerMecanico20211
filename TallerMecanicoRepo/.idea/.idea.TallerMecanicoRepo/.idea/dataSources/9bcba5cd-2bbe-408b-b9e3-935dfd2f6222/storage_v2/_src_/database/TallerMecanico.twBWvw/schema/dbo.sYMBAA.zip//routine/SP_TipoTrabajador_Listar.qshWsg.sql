CREATE PROCEDURE SP_TipoTrabajador_Listar
AS
SELECT	
	CodigoTrabajador,
	NombreCargo,
	DescripcionCargo,
	Permiso_FichaTecnica,
	Permiso_ListadoClientes,
	Permiso_ListadoCompras,
	Permiso_ListadoVentas,
	Permiso_Facturas,
	Permiso_Inventarios,
	Permiso_CreacionUsuarios
FROM TipoTrabajador
go

