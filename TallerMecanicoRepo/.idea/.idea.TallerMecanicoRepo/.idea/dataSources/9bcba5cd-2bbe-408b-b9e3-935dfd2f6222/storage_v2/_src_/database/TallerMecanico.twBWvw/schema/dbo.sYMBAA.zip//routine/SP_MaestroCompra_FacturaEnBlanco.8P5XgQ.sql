CREATE PROCEDURE SP_MaestroCompra_FacturaEnBlanco
AS 
    INSERT INTO MaestroCompra
    (FechaCreacion, FechaModificacion, TotalFactura)
    VALUES 
    (GETDATE(),GETDATE(),0);
    
    SELECT MAX(IdRegistro) AS UltimoRegistro
    FROM MaestroCompra;
go

