CREATE PROCEDURE SP_Trabajador_TraerPorID
	@ID			BIGINT
AS
SELECT
	Cedula,
	Nombres,
	Apellidos,
	Celular,
	TipoTrabajador,
	DireccionCorreoElectronico AS Correo,
	Contraseña AS Clave
FROM 
	Trabajador
WHERE
	Cedula = @ID;
go

