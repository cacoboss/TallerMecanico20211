CREATE PROCEDURE Trabajador_TraerTrabajadorPorIDCorreo
	@ID_CORREO INT
AS
	SELECT * 
	FROM 
		[TallerMecanico].[dbo].[Trabajador]
	WHERE 
		IdentificadorCorreo = @ID_CORREO;
go

