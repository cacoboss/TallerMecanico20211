CREATE PROCEDURE SP_Proveedor_Eliminar
	@ID			INT
AS
DELETE FROM Proveedor
WHERE CodigoProveedor = @ID;
go

