CREATE PROCEDURE SP_Trabajador_Insertar
	@CEDULA		BIGINT,
	@NOMBRES	NVARCHAR(50),
	@APELLIDOS	NVARCHAR(50),
	@CELULAR	BIGINT,
	@TIPO		INT,
	@CORREO		NVARCHAR(50),
	@CLAVE		NVARCHAR(50)
AS
INSERT INTO
Trabajador (
	Cedula,
	Nombres,
	Apellidos,
	Celular,
	TipoTrabajador,
	FechaCreacion,
	FechaModificacion,
	DireccionCorreoElectronico,
	Contraseña
)
VALUES (
	@CEDULA,
	@NOMBRES,
	@APELLIDOS,
	@CELULAR,
	@TIPO,
	GETDATE(),
	GETDATE(),
	@CORREO,
	@CLAVE
)
go

