CREATE PROCEDURE SP_Proveedor_TraerPorID
	@ID		INT
AS
SELECT 
	CodigoProveedor,
	ISNULL(NombreProveedor,'Nombre Vacio'),
	ISNULL(DescripcionProveedor,'Descripcion Vacia')
FROM
	Proveedor
WHERE
	CodigoProveedor = @ID;
go

