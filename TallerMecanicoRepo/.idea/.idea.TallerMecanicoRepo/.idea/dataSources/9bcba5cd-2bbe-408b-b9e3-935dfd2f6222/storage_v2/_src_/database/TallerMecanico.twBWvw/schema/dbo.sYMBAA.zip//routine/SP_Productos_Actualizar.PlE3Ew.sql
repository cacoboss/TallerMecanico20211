CREATE PROCEDURE SP_Productos_Actualizar
	@ID					INT,
	@CODIGOCAT			INT,
	@DESCRIPCION		TEXT,
	@VALORCOMPRA		REAL,
	@VALORVENTA			REAL,
	@MARCA				NVARCHAR(50),
	@NOMBRE				NVARCHAR(50)
AS
UPDATE Productos
SET
	CodigoCategoria = @CODIGOCAT,
	DescripcionProducto = @DESCRIPCION,
	ValorUnitarioCompra = @VALORCOMPRA,
	ValorUnitarioVenta = @VALORVENTA,
	Marca = @MARCA,
	FechaModificacion = GETDATE(),
	NombreProducto = @NOMBRE
WHERE
	CodigoProducto = @ID
go

