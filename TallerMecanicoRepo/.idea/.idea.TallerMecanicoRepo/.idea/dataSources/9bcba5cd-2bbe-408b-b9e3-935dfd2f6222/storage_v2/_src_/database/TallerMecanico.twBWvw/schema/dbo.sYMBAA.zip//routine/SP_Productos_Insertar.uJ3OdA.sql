CREATE PROCEDURE SP_Productos_Insertar
	@CODIGOCAT			INT,
	@DESCRIPCION		TEXT,
	@VALORCOMPRA		REAL,
	@VALORVENTA			REAL,
	@MARCA				NVARCHAR(50),
	@NOMBRE				NVARCHAR(50)
AS
INSERT INTO 
Productos (
	CodigoCategoria,
	DescripcionProducto,
	ValorUnitarioCompra,
	ValorUnitarioVenta,
	Marca,
	FechaCreacion,
	FechaModificacion,
	NombreProducto
)
VALUES
(	@CODIGOCAT,
	@DESCRIPCION,
	@VALORCOMPRA,
	@VALORVENTA,
	@MARCA,
	GETDATE(),
	GETDATE(),
	@NOMBRE
)
go

