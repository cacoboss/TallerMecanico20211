CREATE PROCEDURE SP_Productos_Eliminar
	@ID			INT
AS
DELETE FROM Productos
WHERE CodigoProducto = @ID
go

