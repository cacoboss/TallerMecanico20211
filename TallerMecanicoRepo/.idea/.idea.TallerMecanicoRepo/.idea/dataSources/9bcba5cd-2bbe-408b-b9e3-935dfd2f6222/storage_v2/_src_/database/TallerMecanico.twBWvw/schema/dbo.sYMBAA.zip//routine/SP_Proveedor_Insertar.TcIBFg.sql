CREATE PROCEDURE SP_Proveedor_Insertar
	@NOMBRE			NVARCHAR(50),
	@DESCRIPCION	TEXT
AS
INSERT INTO 
	Proveedor (NombreProveedor, DescripcionProveedor, FechaCreacion, FechaModificacion)
VALUES
	(@NOMBRE,@DESCRIPCION, GETDATE(), GETDATE());
go

