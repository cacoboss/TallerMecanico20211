CREATE TRIGGER [dbo].[AU_Categoria2_Simple] ON [dbo].[Categoria2]
AFTER INSERT,DELETE,UPDATE
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;



DECLARE @TABLA VARCHAR(50)
DECLARE @REGISTRO INT
DECLARE @VALOR_NUEVO VARCHAR(50)
DECLARE @VALOR_ANTIGUO VARCHAR(50)
DECLARE @ACCION VARCHAR(50)
DECLARE @CAMPO VARCHAR(20)
DECLARE @USUARIO VARCHAR(20)
DECLARE @NOMBRE_NUEVO VARCHAR(50)
DECLARE @NOMBRE_ANTIGUO VARCHAR(50)



SET @TABLA = '[dbo].[Categoria2]'



if exists(SELECT * from inserted) and not exists (SELECT * from deleted)
begin
SET @ACCION='Crea'
SET @CAMPO='CodigoCategoria'



select @REGISTRO=i.IdCategoria, @VALOR_NUEVO=i.CodigoCategoria, @USUARIO=i.Usuario
from inserted as i



Insert into [dbo].[AuditoriaGeneral] (Accion, Registro, NuevoValor, Campo, Usuario, Tabla)
VALUES (@ACCION, @REGISTRO, @VALOR_NUEVO, @CAMPO, @USUARIO, @TABLA)
end



if exists(SELECT * from inserted) and exists (SELECT * from deleted)
begin
SET @ACCION='Edita'

select @REGISTRO=i.IdCategoria,
@VALOR_NUEVO=i.CodigoCategoria,
@VALOR_ANTIGUO=d.CodigoCategoria,
@NOMBRE_NUEVO=i.Nombre,
@NOMBRE_ANTIGUO=d.Nombre,
@USUARIO=i.UsuarioEdita
from deleted as d
join inserted as i
on d.IdCategoria=i.IdCategoria



if @VALOR_NUEVO<>@VALOR_ANTIGUO
begin
SET @CAMPO='CodigoCategoria'



Insert into [dbo].[AuditoriaGeneral] (Accion, Registro, NuevoValor, AntiguoValor,Campo, Usuario, Tabla)
VALUES (@ACCION, @REGISTRO, @VALOR_NUEVO, @VALOR_ANTIGUO, @CAMPO, @USUARIO, @TABLA)
end



if @NOMBRE_NUEVO<>@NOMBRE_ANTIGUO
begin
SET @CAMPO='Nombre'



Insert into [dbo].[AuditoriaGeneral] (Accion, Registro, NuevoValor, AntiguoValor,Campo, Usuario, tabla)
VALUES (@ACCION, @REGISTRO, @NOMBRE_NUEVO, @NOMBRE_ANTIGUO, @CAMPO, @USUARIO, @TABLA)
end

end



if not exists(SELECT * from inserted) and exists (SELECT * from deleted)
begin
SET @ACCION='Elimina'
SET @CAMPO='CodigoCategoria'



select @REGISTRO=d.IdCategoria, @VALOR_ANTIGUO=d.CodigoCategoria, @USUARIO=d.usuario
from deleted as d



Insert into [dbo].[AuditoriaGeneral] (Accion, Registro, AntiguoValor,Campo, Usuario, tabla)
VALUES (@ACCION, @REGISTRO, @VALOR_ANTIGUO, @CAMPO, @USUARIO, @TABLA)
end





END
go

