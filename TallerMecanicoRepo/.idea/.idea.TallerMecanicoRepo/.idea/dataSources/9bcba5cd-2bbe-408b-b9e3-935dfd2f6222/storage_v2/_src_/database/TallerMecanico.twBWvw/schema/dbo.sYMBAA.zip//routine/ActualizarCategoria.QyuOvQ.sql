CREATE PROCEDURE ActualizarCategoria
	@ID					INT,
	@CODIGO				VARCHAR(8),
	@NOMBRE				VARCHAR(100),
	@OBSERVACION		TEXT
AS
UPDATE Categoria
SET
	CodigoCategoria = @CODIGO,
	Nombre = @NOMBRE,
	Observacion = @OBSERVACION
WHERE
	IdCategoria = @ID
go

