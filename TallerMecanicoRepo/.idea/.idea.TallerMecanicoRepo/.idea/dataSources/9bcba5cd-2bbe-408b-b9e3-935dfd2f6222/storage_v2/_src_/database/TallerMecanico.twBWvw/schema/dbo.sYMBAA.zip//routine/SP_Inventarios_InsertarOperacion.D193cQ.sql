CREATE PROCEDURE SP_Inventarios_InsertarOperacion
	@IDPRODUCTO	INT,
	@VALOR		REAL,
	@CANTIDAD	INT,
	@TIPO		BIT
AS
INSERT INTO Inventarios
(IdProducto, ValorUnitario, Cantidad, FechaOperacion, CompraVenta)
VALUES
(@IDPRODUCTO, @VALOR, @CANTIDAD, GETDATE(), @TIPO)
go

