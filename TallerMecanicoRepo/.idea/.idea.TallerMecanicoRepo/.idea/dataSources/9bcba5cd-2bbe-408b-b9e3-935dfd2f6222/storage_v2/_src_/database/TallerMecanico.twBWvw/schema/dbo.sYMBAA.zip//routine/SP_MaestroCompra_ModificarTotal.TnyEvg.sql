CREATE PROCEDURE SP_MaestroCompra_ModificarTotal
    @TOTAL          REAL,
    @NUMREGISTRO    INT
AS
    UPDATE MaestroCompra
    SET TotalFactura = @TOTAL
    WHERE IdRegistro = @NUMREGISTRO
go

