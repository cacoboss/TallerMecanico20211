CREATE TRIGGER [dbo].[AU_Productos_Simple] 
   ON  [dbo].[Productos]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @TABLA VARCHAR(50)
DECLARE @REGISTRO INT
--DECLARE @VALOR_NUEVO VARCHAR(50)
--DECLARE @VALOR_ANTIGUO VARCHAR(50)
DECLARE @ACCION VARCHAR(50)
DECLARE @CAMPO VARCHAR(20)
DECLARE @USUARIO VARCHAR(20)
DECLARE @NOMBRE_NUEVO VARCHAR(50)
DECLARE @NOMBRE_ANTIGUO VARCHAR(50)

SET @TABLA = '[dbo].[Productos]'

-- Inserción de Datos
IF EXISTS (SELECT * FROM inserted) AND NOT EXISTS (SELECT * FROM deleted)
BEGIN
	SET @ACCION	=	'Crea'
	SET @CAMPO	=	'NombreProducto'

	SELECT 
		@REGISTRO		= i.CodigoProducto,
		@NOMBRE_NUEVO	= i.NombreProducto 
	FROM inserted AS i

	INSERT INTO [dbo].[AuditoriaGeneral]
		(Accion, Registro, NuevoValor, Campo, Tabla)
	VALUES
		(@ACCION, @REGISTRO, @NOMBRE_NUEVO, @CAMPO, @TABLA)
END


END
go

